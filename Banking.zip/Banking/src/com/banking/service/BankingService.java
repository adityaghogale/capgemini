package com.banking.service;

import com.banking.dao.BankingOperationsImpl;
import com.banking.dao.IBankingOperations;
import com.banking.vo.Address;
import com.banking.vo.BankAccount;
import com.banking.vo.Customer;
import com.banking.vo.SavingsAccount;

public class BankingService implements IBankingService {

	IBankingOperations x = new BankingOperationsImpl();
	
	@Override
	
	public void openAccount(Address address, Customer customer, 
			SavingsAccount savingsAccount, String city, int zipcode,
				int customerNumber, String customerName, int actNumber, 
				int actBalance, int interestRate) {
		
			x.openAccount(address, customer, savingsAccount, city, 
				zipcode, customerNumber, customerName, actNumber, 
				actBalance, interestRate);
		
	}

	@Override
	public void openPayeeAccount(Address address, Customer customer, 
			SavingsAccount savingsAccount, String city,
			int zipcode, int customerNumber, String customerName, 
			int actNumber, int actBalance, int interestRate) {
		
			x.openPayeeAccount(address, customer, savingsAccount, 
				city, zipcode, customerNumber, customerName, 
				actNumber, actBalance, interestRate);
		
	}

	
	@Override
	public void withdraw(BankAccount bankAccount, int withDrawAmount) {
			x.withdraw(bankAccount, withDrawAmount);

	}

	@Override
	public void deposit(BankAccount bankAccount, int depositAmount) {
			x.deposit(bankAccount, depositAmount);

	}

	@Override
	public void showBalance(BankAccount bankAccount) {
			x.showBalance(bankAccount);

	}

	@Override
	public void transferFunds(BankAccount accountSource, BankAccount accountTarget, int transferAmount) {
			x.transferFunds(accountSource, accountTarget, transferAmount);

	}

	
}
