package com.banking.vo;

public class SavingsAccount extends BankAccount {

	private int interestRate;
	
	@Override
	public void computeBalance() {
		double currentBalance = 
				getActBalance() + 
				    ((getActBalance() * getInterestRate())/100);
		
		System.out.println(
				"Savings balance = "+ currentBalance);

	}

	public SavingsAccount() {
		super();
		
	}

	public SavingsAccount(int actNumber, double actBalance, Customer customer) {
		super(actNumber, actBalance, customer);
		
	}

	public SavingsAccount(int interestRate) {
		super();
		this.interestRate = interestRate;
	}

	public int getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(int interestRate) {
		this.interestRate = interestRate;
	}

	
}
