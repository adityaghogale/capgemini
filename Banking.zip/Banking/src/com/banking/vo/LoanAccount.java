package com.banking.vo;

public class LoanAccount extends BankAccount {
	private int actualLoanAmount;
 	private int paidLoanAmount;
 	
	@Override
	public void computeBalance() {
		
		double currentBalance = 
				getActualLoanAmount() - 
				         getPaidLoanAmount() ;
		System.out.println(
				"Loan balance = " + currentBalance);

	}

	public LoanAccount() {
		super();
		
	}

	public LoanAccount(int actNumber, double actBalance, Customer customer) {
		super(actNumber, actBalance, customer);
		
	}

	public LoanAccount(int actualLoanAmount, int paidLoanAmount) {
		super();
		this.actualLoanAmount = actualLoanAmount;
		this.paidLoanAmount = paidLoanAmount;
	}

	public int getActualLoanAmount() {
		return actualLoanAmount;
	}

	public void setActualLoanAmount(int actualLoanAmount) {
		this.actualLoanAmount = actualLoanAmount;
	}

	public int getPaidLoanAmount() {
		return paidLoanAmount;
	}

	public void setPaidLoanAmount(int paidLoanAmount) {
		this.paidLoanAmount = paidLoanAmount;
	}

	
}
