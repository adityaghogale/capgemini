package com.banking.util;

import com.banking.exceptions.AccountNotFoundException;
import com.banking.vo.BankAccount;

public class BankingUtil {

	public static boolean checkForAccount(BankAccount bankAccount)
	{
		if(bankAccount.getActNumber() != 1234)
		{
			try {
				throw new 
				   AccountNotFoundException(
						     bankAccount.
						       getActNumber());
			} catch (AccountNotFoundException e) {
				
				e.printStackTrace();
			}
			
			return false;
			
		}
		return true;
		
	}
}
