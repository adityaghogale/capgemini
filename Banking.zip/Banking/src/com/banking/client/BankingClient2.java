package com.banking.client;

import com.banking.service.BankingService;
import com.banking.service.IBankingService;
import com.banking.vo.Address;
import com.banking.vo.Customer;
import com.banking.vo.SavingsAccount;
import java.util.Scanner;
public class BankingClient2 {

	public static void main(String[] args) {
		
		char ans = 'n';
		int choice = 0;
		String city = "";
		int zipcode = 0; 
		int customerNumber = 0; 
		String customerName = ""; 
		int actNumber = 0; 
		int actBalance = 0; 
		int interestRate = 0;
		int depositAmount = 0;
		int withDrawAmount = 0;
		String acctType = "";
		int transferAmount = 0;
		
		Scanner sc = new Scanner(System.in);
		
		IBankingService bankingService = new BankingService();
		
		Address address_1 = new Address();
		Address address_2 = new Address();
		
		Customer customer_1 = new Customer();
		Customer customer_2 = new Customer();
		
		SavingsAccount savingsAccount_1 = new SavingsAccount();
		SavingsAccount savingsAccount_2 = new SavingsAccount();
		do
		{
			System.out.println("*********Main Menu**********");
			System.out.println("1. Open Account");
			System.out.println("2. Open Payee Account");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Check Details");
			System.out.println("   5.i.  Self  Account");
			System.out.println("   5.ii. Payee Account");
			System.out.println("6. Check Balance");
			System.out.println("   6.i.  Self  Account");
			System.out.println("   6.ii. Payee Account");
			System.out.println("7. Transfer Money");
			System.out.println("8. Exit");
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			sc.nextLine();
			switch(choice)
			{
			case 1:
					System.out.println("Enter city:");
					city = sc.nextLine();
					//sc.nextLine();
					System.out.println("Enter zipcode:");
					zipcode = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter customerNumber:");
					customerNumber = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter customerName:");
					customerName = sc.nextLine();
					//sc.nextLine();
					System.out.println("Enter acctNumber:");
					actNumber = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter actBalance:");
					actBalance = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter interestRate:");
					interestRate = sc.nextInt();
					sc.nextLine();
					bankingService.openAccount(address_1, customer_1, 
							savingsAccount_1, city, zipcode, 
							customerNumber, customerName, actNumber, 
							actBalance, interestRate);
				break;
			case 2:
					System.out.println("Enter city:");
					city = sc.nextLine();
					//sc.nextLine();
					System.out.println("Enter zipcode:");
					zipcode = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter customerNumber:");
					customerNumber = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter customerName:");
					customerName = sc.nextLine();
					//sc.nextLine();
					System.out.println("Enter acctNumber:");
					actNumber = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter actBalance:");
					actBalance = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter interestRate:");
					interestRate = sc.nextInt();
					sc.nextLine();
					bankingService.openPayeeAccount(address_2, customer_2, 
						savingsAccount_2, city, zipcode, 
						customerNumber, customerName, actNumber, 
						actBalance, interestRate);
				break;
			case 3:
					System.out.println("Enter amount to be deposited:");
					depositAmount = sc.nextInt();
					sc.nextLine();
					bankingService.deposit(savingsAccount_1, depositAmount);
				break;
			case 4:
					System.out.println("Enter amount to be withdraw:");
					withDrawAmount = sc.nextInt();
					sc.nextLine();
					bankingService.withdraw(savingsAccount_1, withDrawAmount);
				break;
			case 5:
					System.out.println("Enter Account Type(i.self,ii.payee):");
					acctType = sc.nextLine();
					//sc.nextLine();
					if(acctType.equals("self"))
					{
						System.out.println("Self account details....");
						System.out.print(savingsAccount_1.getActNumber() );
						System.out.print("--" + savingsAccount_1.getCustomer().getCustomerName() );
						System.out.print("--" + savingsAccount_1.getActBalance());
						System.out.print("--" + savingsAccount_1.getInterestRate());

						System.out.println("\n");

					}
					else if(acctType.equals("payee"))
					{
						System.out.println("Payee account details....");
						System.out.print(savingsAccount_2.getActNumber() );
						System.out.print("--" + savingsAccount_2.getCustomer().getCustomerName() );
						System.out.print("--" + savingsAccount_2.getActBalance());
						System.out.print("--" + savingsAccount_2.getInterestRate());

						System.out.println("\n");

					}
					else
					{
						System.out.println("Only self or payee");
					}
				break;
			case 6:
					System.out.println("Enter Account Type(i.self,ii.payee):");
					acctType = sc.nextLine();
					//sc.nextLine();
					if(acctType.equals("self"))
					{
						System.out.println("Self latest balance is ...");
						savingsAccount_1.computeBalance();
					}
					else if(acctType.equals("payee"))
					{
						System.out.println("Payee latest balance is ...");
						savingsAccount_2.computeBalance();
					}
					else
					{
					System.out.println("Only self or payee");
					}
				break;
			case 7:
					System.out.println("Enter amount to be transferred:");
					transferAmount = sc.nextInt();
					sc.nextLine();
					bankingService.transferFunds(savingsAccount_1, savingsAccount_2, transferAmount);
				break;
			case 8:
					System.exit(0);
			default:System.out.println("Sorry wrong choice..");
			}
			System.out.println("Do u want more...");
			ans = sc.next().charAt(0);
		}while(ans == 'y' || ans == 'Y');
		System.out.println("Exiting...");
	}

}
