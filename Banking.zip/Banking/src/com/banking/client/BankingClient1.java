package com.banking.client;

import com.banking.service.BankingService;
import com.banking.service.IBankingService;
import com.banking.vo.Address;
import com.banking.vo.Customer;
import com.banking.vo.SavingsAccount;

public class BankingClient1 {

	public static void main(String[] args) {
		IBankingService bankingService = new BankingService();

		Address ad1 = new Address();
		ad1.setCity("hyderabad");
		ad1.setZipcode(1111);

		Customer c1 = new Customer();
		c1.setCustomerNumber(1234);
		c1.setCustomerName("scott");
		c1.setCustomerAddress(ad1);

		SavingsAccount sa1 = new SavingsAccount();
		sa1.setActNumber(1234);
		sa1.setActBalance(10000);
		sa1.setInterestRate(4);
		sa1.setCustomer(c1);


		System.out.println("Account details....");
		System.out.print(sa1.getActNumber() );
		System.out.print("--" + sa1.getCustomer().getCustomerName() );
		System.out.print("--" + sa1.getActBalance());
		System.out.print("--" + sa1.getInterestRate());

		System.out.println("\n");

		System.out.println("Withdrawing.....");

		bankingService.withdraw(sa1, 5000);

		System.out.println("latest balance is ...");
		sa1.computeBalance();


	}
}
