package com.banking.exceptions;

public class AccountNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int accountNumber;

	public AccountNotFoundException() {
		super();
	
	}

	public AccountNotFoundException(int accountNumber) {
		super();
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "AccountNotFoundException [accountNumber=" + accountNumber + "]";
	}
	
}
