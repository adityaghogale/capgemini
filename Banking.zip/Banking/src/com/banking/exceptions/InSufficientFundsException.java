package com.banking.exceptions;

public class InSufficientFundsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double balance;

	public InSufficientFundsException() {
		super();
		
	}

	public InSufficientFundsException(double balance) {
		super();
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "InSufficientFundsException [balance=" + balance + "]";
	}
	
	
}
