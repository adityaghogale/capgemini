package com.banking.dao;

import com.banking.exceptions.AccountNotFoundException;
import com.banking.exceptions.InSufficientFundsException;
import com.banking.util.BankingUtil;
import com.banking.vo.Address;
import com.banking.vo.BankAccount;
import com.banking.vo.Customer;
import com.banking.vo.SavingsAccount;

public class BankingOperationsImpl implements IBankingOperations {

	@Override
	public void openAccount(Address address, Customer customer, 
			SavingsAccount savingsAccount, String city, int zipcode,
			int customerNumber, String customerName, int actNumber, 
			int actBalance, int interestRate) {
		
		address.setCity(city);
		address.setZipcode(zipcode);
		
		customer.setCustomerName(customerName);
		customer.setCustomerNumber(customerNumber);
		customer.setCustomerAddress(address);
		
		savingsAccount.setActNumber(actNumber);
		savingsAccount.setActBalance(actBalance);
		savingsAccount.setInterestRate(interestRate);
		savingsAccount.setCustomer(customer);
		
	}

	@Override
	public void openPayeeAccount(Address address, Customer customer, 
			SavingsAccount savingsAccount, String city,
			int zipcode, int customerNumber, String customerName, 
			int actNumber, int actBalance,
			int interestRate) {
		
		address.setCity(city);
		address.setZipcode(zipcode);
		
		customer.setCustomerName(customerName);
		customer.setCustomerNumber(customerNumber);
		customer.setCustomerAddress(address);
		
		savingsAccount.setActNumber(actNumber);
		savingsAccount.setActBalance(actBalance);
		savingsAccount.setInterestRate(interestRate);
		savingsAccount.setCustomer(customer);
		
	}

	
	@Override
	public void withdraw(BankAccount bankAccount, int withDrawAmount) {
		 if(BankingUtil.checkForAccount(bankAccount)==false)
		 {
		 return;
		 }
		 
		 
		if(withDrawAmount > bankAccount.getActBalance())
		{
			try {
				throw 
				new InSufficientFundsException
				(withDrawAmount);
			} catch (InSufficientFundsException e) {
				e.printStackTrace();
			}
			
			return;
		}
		
		
		bankAccount.setActBalance
		  (bankAccount.getActBalance() - 
				     withDrawAmount);
		
		System.out.println("Withdraw successful.....");		
		
	}

	@Override
	public void deposit(BankAccount bankAccount, int depositAmount) {
		 if(BankingUtil.checkForAccount(bankAccount)==false)
		 {
		 return;
		 }
		 

		bankAccount.setActBalance
		(bankAccount.getActBalance() + depositAmount);
		 
		System.out.println("Deposit successful..");


	}

	@Override
	public void showBalance(BankAccount bankAccount) {
		
		if(BankingUtil.checkForAccount(bankAccount)==false)
		 {
		 return;
		 }
		
		System.out.println("Balance amount ...."+bankAccount.getActBalance());
	}

	@Override
	public void transferFunds(BankAccount accountSource, BankAccount accountTarget, int transferAmount) {
		// TODO Auto-generated method stub
		if( accountSource.getActNumber() != 1234)
        {
			try
			{
			throw new AccountNotFoundException(1234);
			}
			catch(AccountNotFoundException e)
			{
				e.printStackTrace();
			}
			return;
        }
		if( accountTarget.getActNumber() != 9876)
        {
			try
			{
			throw new AccountNotFoundException(9876);
			}
			catch(AccountNotFoundException e)
			{
				e.printStackTrace();
			}
			return;
        }
		if(transferAmount > accountSource.getActBalance())
		{
			try {
				throw 
				new InSufficientFundsException
				(transferAmount);
			} catch (InSufficientFundsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return;
		}
		
		accountSource.setActBalance
		  (accountSource.getActBalance() - 
				  transferAmount);
		
		accountTarget.setActBalance
		  (accountTarget.getActBalance() + 
				  transferAmount);
		
		System.out.println("Amount transferred....");
	}

	
	
}
