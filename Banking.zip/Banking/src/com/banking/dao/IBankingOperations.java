package com.banking.dao;

import com.banking.vo.Address;
import com.banking.vo.BankAccount;
import com.banking.vo.Customer;
import com.banking.vo.SavingsAccount;

public interface IBankingOperations {
	
	public void openAccount
		(Address address,Customer customer,
				SavingsAccount savingsAccount,String city,
				int zipcode,int customerNumber,String customerName,
				int actNumber,int actBalance,int interestRate);
	
	public void openPayeeAccount
		(Address address,Customer customer,
				SavingsAccount savingsAccount,String city,
				int zipcode,int customerNumber,String customerName,
				int actNumber,int actBalance,int interestRate);
	
	public void withdraw
	   (BankAccount bankAccount, int withDrawAmount);
	 
  public void 
     deposit(BankAccount bankAccount,
     		   int depositAmount);
  public void 
     showBalance(BankAccount bankAccount);
  
  public void transferFunds
     (BankAccount accountSource, 
     		BankAccount accountTarget,
     		   int transferAmount);

}
