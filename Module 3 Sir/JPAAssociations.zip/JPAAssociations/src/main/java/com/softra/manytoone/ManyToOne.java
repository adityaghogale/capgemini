package com.softra.manytoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.softra.utility.EntityManagerHelper;


/*
 * MANY-TO-ONE observations
 * 
 * DEPT table has below values
 * ID	DNAME
 * 1	JavaDepartment
 * 
 * EMPLOYEE table has below values
 * ID	FIRSTNAME	LASTNAME	department_id	
 * 1	Satish		Mandore		1	
 * 2    Amit     	Deshpande   1   
 * 3	Suresh		Raina		1	
 * 
 * OneToMany and ManyToMany - by default lazy fetch
 * ManyToOne and OneToOne - by default eager fetch
 * 
 */

public class ManyToOne {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		//Create Department Entity
		Department department = new Department();
		department.setName("JavaDepartment");
		
		//Store Department
		em.persist(department);
		
		//Create Employee1 Entity
		   Employee employee1 = new Employee();
		   employee1.setFname("Satish");
		   employee1.setLname("Mandore");
		   employee1.setDepartment(department);

		   //Create Employee2 Entity
		   Employee employee2 = new Employee();
		   employee2.setFname("Amit");
		   employee2.setLname("Deshpande");
		   employee2.setDepartment(department);

		   //Create Employee3 Entity
		   Employee employee3 = new Employee();
		   employee3.setFname("Suresh");
		   employee3.setLname("Raina");
		   employee3.setDepartment(department);
		   
		   //Store Employees
		   em.persist(employee1);
		   em.persist(employee2);
		   em.persist(employee3);

		   tx.commit();
		   em.close();
		   
		   EntityManagerHelper.closeFactory();
	}

}


