package com.softra.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.softra.utility.EntityManagerHelper;


/*
 * MANY-TO-ONE observations
 * 
 * TECHSKILL table has below values
 * ID	SKILLNAME
 * 4	Java
 * 5	MicroSoft
 * 
 * EMPLOYEE4 table has below values
 * ID	FIRSTNAME	LASTNAME	
 * 1	Satish		Mandore			
 * 2    Amit     	Deshpande      
 * 3	Suresh		Raina		
 * 
 * TECHSKILL_EMPLOYEE4
 * TECHSKILL_ID		EMPLOYEES_ID
 * 4				1
 * 4				2
 * 5				2
 * 5				3
 * 
 * addTechSkillToEmployee() method
 * 	
 */

public class ManyToMany {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		//Create Employee Entity
		//Department department = new Department();
		//department.setName("JavaDepartment");
		
		//Store Department
		//em.persist(department);
		
		//Create Employee1 Entity
		   Employee employee1 = new Employee();
		   employee1.setFname("Satish");
		   employee1.setLname("Mandore");
		   

		   //Create Employee2 Entity
		   Employee employee2 = new Employee();
		   employee2.setFname("Amit");
		   employee2.setLname("Dudhbhate");
		   

		   //Create Employee3 Entity
		   Employee employee3 = new Employee();
		   employee3.setFname("Suresh");
		   employee3.setLname("Raina");
		  
		   
		   //Store Employees
		   em.persist(employee1);
		   em.persist(employee2);
		   em.persist(employee3);
		   
		   //Create Set of Employees
		   List<Employee> emplist1 = new ArrayList<Employee>();
		   emplist1.add(employee1);
		   emplist1.add(employee2);
		   
		   List<Employee> emplist2 = new ArrayList<Employee>();
		   emplist2.add(employee2);
		   emplist2.add(employee3);
		   
		   //Create TechSkill1 entity
		   TechSkill skill1 = new TechSkill();
		   skill1.setSkillname("Java");
		   skill1.setEmployees(emplist1);
		   
		   //Create TechSkill2 entity
		   TechSkill skill2 = new TechSkill();
		   skill2.setSkillname("MicroSoft");
		   skill2.setEmployees(emplist2);
		   
		   //Store skillsets
		   em.persist(skill1);
		   em.persist(skill2);

		   tx.commit();
		   em.close();
		   
		   EntityManagerHelper.closeFactory();
	}

}


