package com.softra.onetomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity(name="DEPT2")
public class Department {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(name="dname")
	private String name;
	
	//The mappedBy attribute of @OneToMany annotation behaves the same as inverse = true in the xml file. So "employees" is the relationship_owner and not the Department
	//mappedBy attribute and @JoinColumn CANT be used together.
	@OneToMany(targetEntity=Employee.class, mappedBy="department")
	//@OneToMany(targetEntity=Employee.class, cascade=CascadeType.ALL)
	//@JoinColumn(name="deptid") //If JoinColumn is given then relationship owner is Department
	private List<Employee> employees;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
		
}


