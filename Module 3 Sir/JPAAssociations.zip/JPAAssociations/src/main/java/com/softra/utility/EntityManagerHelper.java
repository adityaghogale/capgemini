package com.softra.utility;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EntityManagerHelper {
		
	private static EntityManagerFactory factory = null;
	private EntityManager entityManager = null;
	
	static
	{
		factory = Persistence.createEntityManagerFactory("JPAssociations");	     
	}
	
	public static EntityManager getEntityManager()
	{   	
		//return factory.getCurrentSession();
		return factory.createEntityManager();
	}
	public static void closeFactory() {
		factory.close();
	}

}
