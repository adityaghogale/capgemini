package com.cg.restserv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserResource {

	@Autowired
	private UserService service;

	// @RequestMapping(method = RequestMethod.GET,value = "/users")
	@GetMapping(path = "/users")
	public List<User> retrieveAllUsers() {
		System.out.println("inside retrieveAllUsers() of Controller");
		return service.findAll();
	}

	@GetMapping(path = "/users/{id}")
	public User retrieveUser(@PathVariable int id) {
		System.out.println("inside retrieveUser() of Controller");
		User user = service.findOne(id);
		if(user == null) {
			System.out.println("Invalid user id");
			throw new UserNotFoundException("404: Invalid user id");
		}
		System.out.println("returned user " + user);
		
		return user;
	}
	
	@PostMapping(path="/users")
    public void createUser(@RequestBody User user) {
        System.out.println("inside createUser() of Controller" );
        User savedUser = service.save(user);
    }
	
	@DeleteMapping(path="/users/{id}")
    public void deleteUser(@PathVariable int id) {
            service.deleteOneUser(id); }
}

