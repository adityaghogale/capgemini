package com.cg.restserv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
