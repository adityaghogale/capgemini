package com.cg.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.service.AuthorService;
import com.cg.service.AuthorServiceImpl;
import com.cg.util.EntityManagerHelper;

public class Client {

	public static void main(String[] args) {
		AuthorService service = new AuthorServiceImpl();

		Book b1 = new Book("Alchemist", 900);
		Book b2 = new Book("The white tiger", 800);
		Book b3 = new Book("Sherlock Holmes", 1000);
		Book b4 = new Book("The Hobbit", 400);
		List<Book> books1 = new ArrayList<Book>();
		books1.add(b1);
		books1.add(b2);
		List<Book> books2 = new ArrayList<Book>();
		books2.add(b3);
		books2.add(b4);

		Author auth1 = new Author("Ramesh");
		Author auth2 = new Author("Suresh");

		b1.setAuthor(auth1);
		b2.setAuthor(auth1);
		b3.setAuthor(auth2);
		b4.setAuthor(auth2);

		auth1.setBooks(books1);
		auth2.setBooks(books2);

		// AuthorDao dao=new AuthorDaoImpl();

		service.create(auth1);
		service.create(auth2);

		List<Book> list = service.getByAuthor("Ramesh");
		System.out.println(list);

		List<Book> list1 = service.getByPriceRange();
		System.out.println(list1);

		String name = service.getByBookId(4);
		System.out.println(name);

		// System.out.println(dao.getAuthorByName("Ramesh"));
	}

}
