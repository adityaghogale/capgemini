package com.cg.service;

import java.util.List;

import com.cg.dao.AuthorDao;
import com.cg.dao.AuthorDaoImpl;
import com.cg.entity.Author;
import com.cg.entity.Book;

public class AuthorServiceImpl implements AuthorService{
	private AuthorDao dao;
	public AuthorServiceImpl() {
		dao=new AuthorDaoImpl();
	}
	@Override
	public List<Book> getAllBooks() {
		dao.beginTransaction();
		List<Book> books= dao.getAllBooks();
		dao.commitTransaction();
		return books;
	}

	@Override
	public List<Book> getByAuthor(String name) {
		dao.beginTransaction();
		Author author=dao.getAuthorByName(name);
		List<Book> list=dao.getByAuthor(author.getAuthorid());
		dao.commitTransaction();
		return list;
	}

	@Override
	public List<Book> getByPriceRange() {
		dao.beginTransaction();
		List<Book> list=dao.getByPriceRange();
		dao.commitTransaction();
		return list;
	}

	@Override
	public String getByBookId(int id) {
		dao.beginTransaction();
		String name=dao.getByBookId(id);
		return name;
	}
	@Override
	public void create(Author author) {
		dao.beginTransaction();
		dao.create(author);
		dao.commitTransaction();
		
	}

}
