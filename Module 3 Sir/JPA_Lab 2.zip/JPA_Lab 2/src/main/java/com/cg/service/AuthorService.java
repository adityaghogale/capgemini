package com.cg.service;

import java.util.List;

import com.cg.entity.Author;
import com.cg.entity.Book;

public interface AuthorService {
	public List<Book> getAllBooks();

	public List<Book> getByAuthor(String name);

	public List<Book> getByPriceRange();

	public String getByBookId(int id);
	
	public void create(Author author);
}
