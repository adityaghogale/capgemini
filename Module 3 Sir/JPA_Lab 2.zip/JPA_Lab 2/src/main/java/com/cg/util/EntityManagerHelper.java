package com.cg.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EntityManagerHelper {
	private static EntityManagerFactory factory = null;
	private EntityManager entityManager = null;
	
	static
	{
		factory = Persistence.createEntityManagerFactory("Jpa_LabNo2");	     
	}
	
	public static EntityManager getEntityManager()
	{   	
		//return factory.getCurrentSession();
		return factory.createEntityManager();
	}
	public static void closeFactory() {
		factory.close();
	}
}
