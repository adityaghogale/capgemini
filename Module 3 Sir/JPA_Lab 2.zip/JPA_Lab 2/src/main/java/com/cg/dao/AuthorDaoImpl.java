package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.entity.Author;
import com.cg.entity.Book;
import com.cg.util.EntityManagerHelper;

public class AuthorDaoImpl implements AuthorDao {

	EntityManager manager;

	// EntityTransaction tx;
	public AuthorDaoImpl() {
		manager = EntityManagerHelper.getEntityManager();
	}

	@Override
	public void beginTransaction() {
		manager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		manager.getTransaction().commit();
	}

	@Override
	public List<Book> getAllBooks() {
		List<Book> list = new ArrayList<Book>();
		list = manager.createQuery("FROM Book").getResultList();
		return list;
	}

	@Override
	public List<Book> getByAuthor(int id) {
		List<Book> books = manager.createQuery("from Book where author_authorid=" + id, Book.class).getResultList();
		return books;
	}

	@Override
	public List<Book> getByPriceRange() {
		List<Book> books = manager.createQuery("from Book where price between 500 And 1000").getResultList();
		return books;
	}

	@Override
	public String getByBookId(int id) {
		Author author=manager.find(Author.class, id);
		return author.getName();
	}

	@Override
	public Author getAuthorByName(String authName) {
		Author author=manager.createQuery("from Author where name = '" + authName + "'", Author.class).getSingleResult();
		return author;
	}

	@Override
	public Book getBookById(int id) {
		return manager.find(Book.class, id);
	}

	@Override
	public void create(Author author) {
		manager.persist(author);
		
	}
}
