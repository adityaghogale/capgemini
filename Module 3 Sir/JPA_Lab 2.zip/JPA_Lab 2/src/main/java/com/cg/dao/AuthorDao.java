package com.cg.dao;

import java.util.List;

import com.cg.entity.Author;
import com.cg.entity.Book;

public interface AuthorDao {
	public List<Book> getAllBooks();
	
	public List<Book> getByAuthor(int id);
	
	public List<Book> getByPriceRange();
	
	public String getByBookId(int id);
	
	public Author getAuthorByName(String authName);
	
	public Book getBookById(int id);
	
	public void beginTransaction();

	public void commitTransaction();
	
	public void create(Author author);
}
