package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Student;

public class StudentDaoImpl implements StudentDao {

	private HashMap<Integer,Student> students;
	
	public StudentDaoImpl() { 
		students=new HashMap<Integer,Student>();
	}
	
	
	@Override
	public int persist(int roll,Student std) {
		
		students.put(roll, std);
		return 0;
	}

	@Override
	public Student search(int rollNo) {
		
		return students.get(rollNo);
	}

	@Override
	public boolean delete(int rollNo) {
		
		Student st=students.remove(rollNo);
		return st !=null?true:false ;
	}

}
