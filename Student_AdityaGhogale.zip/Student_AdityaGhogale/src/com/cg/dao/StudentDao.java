package com.cg.dao;

import com.cg.bean.Student;

public interface StudentDao {

	int persist(int roll, Student std);
	
	Student search(int rollNo);
	
	boolean delete(int rollNo);
}
