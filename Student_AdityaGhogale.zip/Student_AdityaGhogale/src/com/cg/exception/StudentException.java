package com.cg.exception;

/**This class represent Invalid Roll Number exception
 * 
 * @author Aditya Ghogale
 *@version 1.0
 */
public class StudentException extends Exception {

	private int rollNO;

	public StudentException(int rollNO) {
		this.rollNO = rollNO;
	}

	@Override
	public String toString() {
		return "StudentException: Invalid Roll number";
	}
	
	
	
}
