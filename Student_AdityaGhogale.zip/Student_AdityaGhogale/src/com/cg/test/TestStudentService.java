package com.cg.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.bean.Student;
import com.cg.service.StudentService;
import com.cg.service.StudentServiceImpl;

class TestStudentService {

	private static StudentService sc = new StudentServiceImpl();
	Student temp = new Student();
	int roll;

	@BeforeClass
	public void setup() {

		temp.setName("Aditya");
		temp.setAge(16);
		temp.setMobile("9654325476");
		temp.setEmail("adi@gmail.com");
		roll = sc.persist(temp);

	}

	@Test
	public void testValidAge() {
		assertEquals(true, StudentService.validateAge(16));
	}

	@Test
	public void testInvalidAge() {
		assertEquals(false, StudentService.validateAge(21));
	}

	@Test
	public void testValidPersist() {
		int tmp = sc.persist(temp);
		assertNotNull(tmp);
	}

	@Test
	public void testValidSearch() {
		int tmp = sc.persist(temp);
		assertNotNull(sc.search(tmp));
	}

	@Test
	public void testInvalidSearch() {
		int invRoll = 103;
		int assignRoll = sc.persist(temp);
		assertNotEquals(sc.search(invRoll), sc.search(assignRoll));
	}

	@Test
	public void testValidDelete() {
		int tmp = sc.persist(temp);
		assertTrue(sc.delete(tmp));
	}

	@Test
	public void testInvalidDelete() {
		int invRoll = 103;
		// int assignRoll=sc.persist(temp);
		assertFalse(sc.delete(invRoll));
	}
	/*
	 * @Test public void testInvalidPersist() { Student tmp2=new Student(); int
	 * tmp=sc.persist(tmp2); assertEquals()
	 * 
	 * }
	 */
}
