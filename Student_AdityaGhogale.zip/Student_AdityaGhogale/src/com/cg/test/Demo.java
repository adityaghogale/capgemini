package com.cg.test;

import com.cg.bean.Student;

public class Demo {

	public static void main(String[] args) {
		Student temp=new Student("Aditya",16,"9273625342","Aditya@gmail.com");
		temp.setRollNo(101);
		
		System.out.println(temp);

	}

}
