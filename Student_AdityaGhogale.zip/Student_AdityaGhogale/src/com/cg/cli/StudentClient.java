package com.cg.cli;

import java.util.Scanner;

import com.cg.bean.Student;
import com.cg.exception.StudentException;
import com.cg.service.StudentService;
import com.cg.service.StudentServiceImpl;

public class StudentClient {

	private static StudentService service = new StudentServiceImpl();

	public static void main(String[] args) throws Exception {


		/*
		 * String name = null, mobile = null, email = null; int age = 0;
		 */
		int option = 0;

		do {
			Scanner console = new Scanner(System.in);
			System.out.println("1-Add Student");
			System.out.println("2-Search Student");
			System.out.println("3-Delete Student");
			System.out.println("4-Exit Application");
			option = console.nextInt();

			switch (option) {
			case 1:
				addStudent();
				break;
			case 2:
				searchStudent();
				break;
			case 3:
				deleteStudent();
				break;
			case 4:
				System.exit(0);

			default:
				System.out.println("Invalid option");
			}

		} while (true);

	}

	private static void deleteStudent() throws StudentException {
		Scanner console = new Scanner(System.in);
		System.out.println("Enter Roll No. to delete student");
		int rollNo = console.nextInt();
		if (service.delete(rollNo))
			System.out.println("Student record deleted");
		else
			throw new StudentException(rollNo);
	}

	private static void searchStudent() throws StudentException {
		Scanner console = new Scanner(System.in);
		System.out.println("Enter Roll No. to search student");
		int rollNo = console.nextInt();
		Student stud = service.search(rollNo);
		if (stud != null) {
			System.out.println("Student Details");
			System.out.println("Roll No: " + stud.getRollNo());
			System.out.println("Student Name: " + stud.getName());
			System.out.println("Student Age: " + stud.getAge());
			System.out.println("Student Mobile: " + stud.getMobile());
			System.out.println("Student Email: " + stud.getEmail());
			
		} else
			throw new StudentException(rollNo);
	}

	private static void addStudent() {
		Student stud = new Student();
		String name = null, mobile = null, email = null;
		int age = 0;
		Scanner console = new Scanner(System.in);
		do {
			System.out.println("Enter Student name: ");
			name = console.nextLine();
			if (!StudentService.validateName(name))
				System.out.println("Invalid name ");
			else
				break;
		} while(true);
		
		do {
			System.out.println("Enter Student Mobile Number: ");
			mobile = console.nextLine();
			if (!StudentService.validateMobile(mobile))
				System.out.println("Invalid mobile name ");
			else
				break;
		} while(true);
		do {
			System.out.println("Enter Student Email: ");
			email = console.nextLine();
			if (!StudentService.validateEmail(email))
				System.out.println("Invalid Email");
			else
				break;
		} while(true);
		do {
			System.out.println("Enter Student Age: ");
			age = console.nextInt();
			if (!StudentService.validateAge(age))
				System.out.println("Invalid Age ");
			else
				break;
		} while(true);

		stud.setName(name);
		stud.setAge(age);
		stud.setMobile(mobile);
		stud.setEmail(email);
		int roll = service.persist(stud);
		System.out.println("Student added with roll number " + roll);
	}

}
