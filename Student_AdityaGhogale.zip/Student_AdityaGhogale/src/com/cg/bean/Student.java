package com.cg.bean;

/**
 * This class represents Student in domain
 * 
 * @author Aditya Ghogale
 * @version 1.0
 *
 */
public class Student {

	public Student(String name, int age, String mobile, String email) {
		
		this.name = name;
		this.age = age;
		this.mobile = mobile;
		this.email = email;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", age=" + age + ", mobile=" + mobile + ", email="
				+ email + "]";
	}

	private int rollNo;
	private String name;
	private int age;
	private String mobile;
	private String email;

	public Student() {
		
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
