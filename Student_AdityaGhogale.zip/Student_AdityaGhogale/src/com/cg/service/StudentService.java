package com.cg.service;

import com.cg.bean.Student;

public interface StudentService {

	int persist(Student std);
	
	Student search(int rollNo);
	
	boolean delete(int rollNo);
	
	
	String namePattern="[A-Za-z]{4,}";
	
	String mobilePattern="[7-9][0-9]{9}";
	
	String emailPattern="^[A-Za-z0-9+_.-]+@(.+)$";
	
	static boolean validateName(String name) {
		return name.matches(namePattern);
	}
	
	static boolean validateMobile(String mobile) {
		return mobile.matches(mobilePattern);
	}
	
	static boolean validateEmail(String email) {
		return email.matches(emailPattern);
	}
	
	
	static boolean validateAge(int age) {
		return age<=18 && age>=12;
	}
}
