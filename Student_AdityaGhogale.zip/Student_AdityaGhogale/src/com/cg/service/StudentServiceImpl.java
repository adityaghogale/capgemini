package com.cg.service;

import com.cg.bean.Student;
import com.cg.dao.StudentDao;
import com.cg.dao.StudentDaoImpl;

public class StudentServiceImpl implements StudentService {

	private StudentDao dao;
	
	
	public StudentServiceImpl() {
		dao=new StudentDaoImpl();
	}
	
	
	private final int generateRollNo() {
		return (int)(Math.random()*300);
	}
	
	
	@Override
	public int persist(Student std) {
		int roll=generateRollNo();
		std.setRollNo(roll);
		dao.persist(roll,std);
		return roll;
	}

	@Override
	public Student search(int rollNo) {
		
		return dao.search(rollNo);
	}

	@Override
	public boolean delete(int rollNo) {
		// send roll no. to delete student
		return dao.delete(rollNo);
	}

}
