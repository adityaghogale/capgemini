
package my.prj.client;

import java.util.List;
import java.util.Scanner;

import my.prj.bean.Customer;
import my.prj.bean.Mobile;
import my.prj.service.MobileAppService;
import my.prj.service.MobileAppServiceImpl;

public class MobileAppClient {

	private static MobileAppService maService;
	public static void main(String[] args){
		maService=new MobileAppServiceImpl();
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("ENter choice:");
			System.out.println("1-viewCustomer \t 2-viewAllCust \t 3-viewMobile \n 4-viewAllMobile \t 5-placeOrder \t 6-viewOrder \t 7-Exit");
			switch(sc.nextInt()){
			case 1:
				System.out.println("Enter id");
				System.out.println(maService.viewCustomer(sc.nextInt()));
				break;
			case 2:
				List<Customer> custDemo=maService.viewAllCustomer();
				custDemo.stream().forEach(System.out::println);
				break;
			case 3:
				System.out.println("Enter mobile id");
				System.out.println(maService.viewMobile(sc.nextInt()));
				break;
			case 4:
				List<Mobile> mobDemo=maService.viewAllMobile();
				mobDemo.stream().forEach(System.out::println);
				break;
			case 5:
				System.out.println("Enter mobile id:");
				int mobId=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter Customer Id:");
				int custId=sc.nextInt();
				System.out.println("Order place with id : "+maService.buyMobile(maService.viewMobile(mobId),maService.viewCustomer(custId)));
				break;
			case 6:
				System.out.println("Enter purchase Id");
				int purId=sc.nextInt();
				System.out.println(maService.viewPurchaseDetails(purId));
				break;
			case 7:
				System.exit(0);
			default:
				System.out.println("Wrong choice");
				
			}
		}while(true);
	}
}
