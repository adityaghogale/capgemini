package my.prj.bean;

import java.time.LocalDate;

public class MobileTransaction {

	private Customer cust;
	private Mobile mob;
	private int transactionId;
	private LocalDate purchaseDate;
	
	public MobileTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "MobileTransaction [cust=" + cust + ", mob=" + mob
				+ ", transactionId=" + transactionId + ", purchaseDate="
				+ purchaseDate + "]";
	}
	public MobileTransaction(Customer cust, Mobile mob, int transactionId,
			LocalDate purchaseDate) {
		super();
		this.cust = cust;
		this.mob = mob;
		this.transactionId = transactionId;
		this.purchaseDate = purchaseDate;
	}
	public Customer getCust() {
		return cust;
	}
	public void setCust(Customer cust) {
		this.cust = cust;
	}
	public Mobile getMob() {
		return mob;
	}
	public void setMob(Mobile mob) {
		this.mob = mob;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	
}
