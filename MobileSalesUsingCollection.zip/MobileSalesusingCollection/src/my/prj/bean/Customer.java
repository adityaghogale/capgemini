package my.prj.bean;

public class Customer {

	private int custId;
	private String custName;
	private String mobileNumber;
	
	
	public Customer(int custId, String custName, String mobileNumber) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.mobileNumber = mobileNumber;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName
				+ ", mobileNumber=" + mobileNumber + "]";
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
}
