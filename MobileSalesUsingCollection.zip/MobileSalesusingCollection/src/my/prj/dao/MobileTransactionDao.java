package my.prj.dao;

import my.prj.bean.Customer;
import my.prj.bean.Mobile;
import my.prj.bean.MobileTransaction;

public interface MobileTransactionDao {

	int buyMobile(int transactionId,Mobile mob,Customer cust);
	MobileTransaction viewPurchaseDetails(int transactionId);
}
