package my.prj.dao;

import java.util.List;

import my.prj.bean.Customer;

public interface CustomerDao {

	Customer viewCustomer(int customerId);
	List<Customer> viewAllCustomer();
}
