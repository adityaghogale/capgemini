package my.prj.dao;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import my.prj.bean.Customer;
import my.prj.bean.Mobile;
import my.prj.bean.MobileTransaction;

public class MobileTransactionDaoImpl implements MobileTransactionDao {

	private static Map<Integer,MobileTransaction> mobTrans;
	
	public MobileTransactionDaoImpl() {
		mobTrans=new HashMap<>();
	}

	@Override
	public int buyMobile(int transactionId, Mobile mob, Customer cust) {
		MobileTransaction tmpTrans=new MobileTransaction();
		tmpTrans.setCust(cust);
		tmpTrans.setMob(mob);
		tmpTrans.setTransactionId(transactionId);
		tmpTrans.setPurchaseDate(LocalDate.now());
		mobTrans.put(transactionId, tmpTrans);
		return transactionId;
	}

	@Override
	public MobileTransaction viewPurchaseDetails(int transactionId) {
		return mobTrans.get(transactionId);
	}

}
