package my.prj.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import my.prj.bean.Mobile;

public class MobileDaoImpl implements MobileDao {

	private static Map<Integer,Mobile> mobile;
	
	public MobileDaoImpl() {
		mobile=new HashMap<Integer,Mobile>();
		mobile.put(10001,new Mobile(10001, "Sony", 170000));
		mobile.put(10002,new Mobile(10002, "Nokia", 270000));
		mobile.put(10003,new Mobile(10003, "Mi", 150000));
		mobile.put(10004,new Mobile(10004, "Apple", 770000));
	}

	@Override
	public Mobile viewMobile(int mobileId) {
		return mobile.get(mobileId);
	}

	@Override
	public List<Mobile> viewAllMobile() {
		return mobile.values().stream().collect(Collectors.toList());
	}

}
