package my.prj.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import my.prj.bean.Customer;

public class CustomerDaoImpl implements CustomerDao {


	private static Map<Integer,Customer> customer;
	
	public CustomerDaoImpl() {
		customer=new HashMap<>();
		customer.put(101,new Customer(101, "Raju", "826352436"));
		customer.put(102,new Customer(102, "Jadu", "826352424"));
		customer.put(103,new Customer(103, "Fadu", "826352423"));
		customer.put(104,new Customer(104, "Gaju", "826327436"));
		customer.put(105,new Customer(105, "Baju", "843252436"));
		customer.put(106,new Customer(106, "Kaju", "822652436"));
	}

	@Override
	public Customer viewCustomer(int customerId) {
		
		return customer.get(customerId);
	}

	@Override
	public List<Customer> viewAllCustomer() {
		return customer.values().stream().collect(Collectors.toList());
	}
	
}
