package my.prj.dao;

import java.util.List;

import my.prj.bean.Mobile;

public interface MobileDao {

	Mobile viewMobile(int mobileId);
	List<Mobile> viewAllMobile();
}
