package my.prj.service;

import java.util.List;

import my.prj.bean.Customer;
import my.prj.bean.Mobile;
import my.prj.bean.MobileTransaction;

public interface MobileAppService {

	Customer viewCustomer(int customerId);
	List<Customer> viewAllCustomer();
	Mobile viewMobile(int mobileId);
	List<Mobile> viewAllMobile();
	int buyMobile(Mobile mob,Customer cust);
	MobileTransaction viewPurchaseDetails(int transactionId);
	
}
