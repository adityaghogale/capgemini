package my.prj.service;

import java.util.List;
import java.util.Random;

import my.prj.bean.Customer;
import my.prj.bean.Mobile;
import my.prj.bean.MobileTransaction;
import my.prj.dao.CustomerDao;
import my.prj.dao.CustomerDaoImpl;
import my.prj.dao.MobileDao;
import my.prj.dao.MobileDaoImpl;
import my.prj.dao.MobileTransactionDao;
import my.prj.dao.MobileTransactionDaoImpl;

public class MobileAppServiceImpl implements MobileAppService {

	private static CustomerDao cdao;
	private static MobileDao mdao;
	private static MobileTransactionDao mtdao;
	
	public MobileAppServiceImpl() {
		cdao=new CustomerDaoImpl();
		mdao=new MobileDaoImpl();
		mtdao=new MobileTransactionDaoImpl();
	}

	@Override
	public Customer viewCustomer(int customerId) {
		
		return cdao.viewCustomer(customerId);
	}

	@Override
	public List<Customer> viewAllCustomer() {
		// TODO Auto-generated method stub
		return cdao.viewAllCustomer();
	}

	@Override
	public Mobile viewMobile(int mobileId) {
		// TODO Auto-generated method stub
		return mdao.viewMobile(mobileId);
	}

	@Override
	public List<Mobile> viewAllMobile() {
		// TODO Auto-generated method stub
		return mdao.viewAllMobile();
	}

	@Override
	public int buyMobile(Mobile mob, Customer cust) {
		// TODO Auto-generated method stub
		int transactionId=generateId();
		return mtdao.buyMobile(transactionId, mob, cust);
	}

	private int generateId() {
		Random r=new Random();
		return r.nextInt(1000)*356;
	}

	@Override
	public MobileTransaction viewPurchaseDetails(int transactionId) {
		// TODO Auto-generated method stub
		return mtdao.viewPurchaseDetails(transactionId);
	}

}
