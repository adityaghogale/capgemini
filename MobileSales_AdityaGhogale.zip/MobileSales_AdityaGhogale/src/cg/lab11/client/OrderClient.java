package cg.lab11.client;

import java.util.Scanner;

import cg.lab11.bean.Customer;
import cg.lab11.service.CustomerService;
import cg.lab11.service.CustomerServiceImpl;
import cg.lab11.service.MobileService;
import cg.lab11.service.MobileServiceImpl;
import cg.lab11.service.PurchaseService;
import cg.lab11.service.PurchaseServiceImpl;

public class OrderClient {

	private static CustomerService custService;
	private static PurchaseService purchaseService;
	private static MobileService mobileService;

	public static void main(String[] args) {
		
		do{
			Scanner console = new Scanner(System.in);
			String choice;
			System.out.println("What do you want to do: 1- Add Customer \n 2-Purchase Phone \n 3-View Your Booking \n 4-Delete Mobiles \n 5-Custom Search \n 6-Exit(x)");
			switch(console.nextInt()){
			case 1:
				createCustomerAccount();
				break;
			case 2:
				purchaseMobile();
				break;
			case 3:
				viewPurchase();
				break;
			case 4:
				deletePhone();
			case 5:
				customSearch();
			case 6:
				System.exit(0);
			default:
				System.out.println("Wrong choice");
			}
			
			
		}while(true);
		

	}
	
	private static void customSearch() {
		mobileService=new MobileServiceImpl();
		Scanner console=new Scanner(System.in);
		int startingRange,finalAmount;
		System.out.println("Enter starting amount");
		startingRange=console.nextInt();
		System.out.println("Enter final amount");
		finalAmount=console.nextInt();
		mobileService.search(startingRange,finalAmount);
		
		
	}

	private static void deletePhone() {
		mobileService=new MobileServiceImpl();
		Scanner console=new Scanner(System.in);
		System.out.println("Enter mobile id to remove");
		System.out.println(mobileService.delete(console.nextInt()));
		System.out.println("DOne");
		
	}

	private static void viewPurchase() {
		purchaseService=new PurchaseServiceImpl();
		Scanner console=new Scanner(System.in);
		System.out.println("Enter purchase id to view details ");
		purchaseService.viewDetails(console.nextInt());
	}

	private static void purchaseMobile() {
		purchaseService=new PurchaseServiceImpl();
		mobileService=new MobileServiceImpl();
		Scanner console=new Scanner(System.in);
		int tempProductCode;
		tempProductCode=mobileService.showMobileList();
		System.out.println("Enter selected phone code:");
		switch(console.nextInt()){
		case 1001:
			System.out.println("Enter your customer id");
			System.out.println("Order is confirm with purchaseID :"+purchaseService.placeOrder(console.nextInt(),1001));
			break;
		case 1002:
			System.out.println("Enter your customer id");
			System.out.println("Order is confirm with purchaseID :"+purchaseService.placeOrder(console.nextInt(), 1002));
			break;
		case 1003:
			System.out.println("Enter your customer id");
			System.out.println("Order is confirm with purchaseID :"+purchaseService.placeOrder(console.nextInt(), 1003));
			break;
		default: System.out.println("Wrong Choice");
		
		}
	
	}

	private static void createCustomerAccount(){
		custService = new CustomerServiceImpl();
		Scanner console = new Scanner(System.in);
		Customer cust = new Customer();
		String name = null, email = null, phone = null;
		int tempId;
		do {
			System.out.println("Enter Customer name: ");
			name = console.nextLine();
			if (!CustomerService.validateName(name))
				System.out.println("Invalid name ");
			else
				break;
		} while(true);
		do {
			System.out.println("Enter Customer Email: ");
			email = console.nextLine();
			if (!CustomerService.validateEmail(email))
				System.out.println("Invalid Email");
			else
				break;
		} while(true);
		
		do {
			System.out.println("Enter Customer Mobile Number: ");
			phone = console.nextLine();
			if (!CustomerService.validateMobile(phone))
				System.out.println("Invalid mobile name ");
			else
				break;
		} while(true);
		cust.setCustName(name);
		cust.setCustEmail(email);
		cust.setCustPhone(phone);
		tempId = custService.addCustomer(cust);
		System.out.println("Customer created with id: " + tempId);
	}

}
