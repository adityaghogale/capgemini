package cg.lab11.dao;

import cg.lab11.bean.Customer;

public interface CustomerDao {
	int addCustomer(int custKey, Customer cust);

	Customer search(int custKey);

	boolean delete(int id);

}
