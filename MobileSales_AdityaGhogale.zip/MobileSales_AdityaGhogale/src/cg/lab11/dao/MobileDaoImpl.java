package cg.lab11.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import cg.lab11.bean.Mobile;

public class MobileDaoImpl implements MobileDao {

	/*@Override
	public int addMobile(int mobileId, Mobile mobile) {
		// TODO Auto-generated method stub
		return 0;
	}*/

	@Override
	public int showMobileList() {
		Scanner console=new Scanner(System.in);

		try {
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			Connection conn = 
			DriverManager.getConnection (
			"jdbc:oracle:thin:@localhost:1521:XE", "adi", "a1234");
			Statement fetchMobiles= conn.createStatement();
			ResultSet mobileList=fetchMobiles.executeQuery("Select mobileid,name,price from mobiles");
			System.out.println("    Mobile Name --------------- Price");
			while(mobileList.next()){
				System.out.println(mobileList.getInt(1)+" "+mobileList.getString(2)+"        "+mobileList.getDouble(3));	
			}}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
			
		return 1;
	}

	@Override
	public boolean delete(int id) {

		try {
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			Connection conn = 
			DriverManager.getConnection (
			"jdbc:oracle:thin:@localhost:1521:XE", "adi", "a1234");
			Statement stmt = conn.createStatement (); 
			int count = stmt.executeUpdate ("delete from mobiles where mobileid="+id);
			System.out.println("Mobile Details deleted ");
			}
		catch (Exception e) {
			System.out.println(e);
		}
			
		return true;
	}


	@Override
	public void search(int sAmount, int fAmount) {
		
		try {
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			Connection conn = 
			DriverManager.getConnection (
			"jdbc:oracle:thin:@localhost:1521:XE", "adi", "a1234");
			Statement fetchMobiles= conn.createStatement();
			ResultSet mobileList=fetchMobiles.executeQuery("Select mobileid,name,price from mobiles where price between "+sAmount+" and "+fAmount);
			System.out.println("    Mobile Name --------------- Price");
			while(mobileList.next()){
				System.out.println(mobileList.getInt(1)+" "+mobileList.getString(2)+"        "+mobileList.getDouble(3));	
			}}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

}
