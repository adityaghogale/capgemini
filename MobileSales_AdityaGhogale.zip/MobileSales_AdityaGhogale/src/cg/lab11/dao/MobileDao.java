package cg.lab11.dao;

import cg.lab11.bean.Mobile;

public interface MobileDao {

	//int addMobile(int mobileId, Mobile mobile);
	
	int showMobileList();

	void search(int sAmount,int fAmount);

	boolean delete(int id);
}
