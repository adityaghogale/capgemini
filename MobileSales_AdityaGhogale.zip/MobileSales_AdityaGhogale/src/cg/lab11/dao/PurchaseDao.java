package cg.lab11.dao;

public interface PurchaseDao {
	int placeOrder(int purchaseId, int custId, int mobileId);

	void viewDetails(int purchaseId);
	
}
