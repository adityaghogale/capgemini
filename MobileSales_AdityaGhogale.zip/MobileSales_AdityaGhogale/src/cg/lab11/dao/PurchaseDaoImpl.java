package cg.lab11.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PurchaseDaoImpl implements PurchaseDao {
	
	//Will confirm a purchase and add record to purchasedetails table
	@Override
	public int placeOrder(int purchaseId, int custId, int mobileId) {
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "adi", "a1234");
			PreparedStatement stmt = conn
					.prepareStatement("insert into purchasedetails values(?,?,?,?,?,?)");

			ResultSet custDetail;
			ResultSet mobileQty;
			Statement temp1 = conn.createStatement();
			custDetail = temp1.executeQuery("Select * from customer where id="
					+ custId);
			Statement temp2 = conn.createStatement();
			mobileQty=temp2.executeQuery("Select * from mobiles where mobileid="+mobileId); 
			
			while (custDetail.next()) {
				while(mobileQty.next()){
				if(mobileQty.getInt(4)>=0){
				stmt.setInt(1, purchaseId);
				stmt.setString(2, custDetail.getString(2));
				stmt.setString(3, custDetail.getString(3));
				stmt.setString(4, custDetail.getString(4));
				stmt.setDate(5,java.sql.Date.valueOf(java.time.LocalDate.now()));
				stmt.setInt(6, mobileId);
				stmt.execute();
				String mobileUpdate="Update mobiles set quantity="+(mobileQty.getInt(4)-1)+"where mobileId="+mobileId;
				PreparedStatement ps=conn.prepareStatement(mobileUpdate);
				System.out.println(ps.executeUpdate());
				System.out.println("Order Placed");
				}
				else{
					System.out.println("Out Of Stock");
				}
			}
			}
			
			custDetail.close();
			conn.commit();
			conn.close();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return purchaseId;
	}

	//this will display record of customer based on inputed purchase id
	@Override
	public void viewDetails(int purchaseId) {
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "adi", "a1234");
			ResultSet custDetail;
			Statement temp1 = conn.createStatement();
			custDetail = temp1.executeQuery("Select * from purchasedetails where purchaseid="+purchaseId);
			while (custDetail.next()) {
				System.out.println("Purchase Id :"+custDetail.getInt(1));
				System.out.println("Customer name:"+custDetail.getString(2));
				System.out.println("Customer Mail :"+custDetail.getString(3));
				System.out.println("Customer Mobile number :"+custDetail.getString(4));
				System.out.println("Purchase Date :"+custDetail.getDate(5));
				System.out.println("Mobile Id :"+custDetail.getInt(6));
			}
			conn.close();
			
		} catch (Exception e) {
			
			System.out.println(e);
		}
	}

}
