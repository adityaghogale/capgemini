package cg.lab11.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import cg.lab11.bean.Customer;

public class CustomerDaoImpl implements CustomerDao {
	

	@Override
	public int addCustomer(int custKey, Customer cust) {
		try	{
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			Connection conn = 
			DriverManager.getConnection (
			"jdbc:oracle:thin:@localhost:1521:XE", "adi", "a1234");
			PreparedStatement stmt = conn.prepareStatement("insert into customer values(?,?,?,?)"); 
			stmt.setInt(1, custKey);
			stmt.setString(2, cust.getCustName());
			stmt.setString(3, cust.getCustEmail());
			stmt.setString(4, cust.getCustPhone());
			stmt.execute();
			conn.commit();
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return custKey;
	}

	@Override
	public Customer search(int custKey) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
