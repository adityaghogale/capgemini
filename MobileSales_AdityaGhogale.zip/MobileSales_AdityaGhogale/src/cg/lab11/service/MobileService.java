package cg.lab11.service;

import cg.lab11.bean.Mobile;

public interface MobileService {
	//int addMobile(int mobileId, Mobile mobile);
	
	int showMobileList();

	void search(int sAmount,int fAmount);

	boolean delete(int id);
}
