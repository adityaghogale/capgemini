package cg.lab11.service;

import java.util.Random;

import cg.lab11.bean.Customer;
import cg.lab11.dao.CustomerDao;
import cg.lab11.dao.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {
	private CustomerDao cdao;
	public CustomerServiceImpl() {
		cdao=new CustomerDaoImpl();
	}

	

	@Override
	public int addCustomer(Customer cust) {
		int custKey = generateId();
		cdao.addCustomer(custKey, cust);
		return custKey;
	}

	@Override
	public Customer search(int custKey) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	private final int generateId() {
		Random r = new Random();
		return r.nextInt(1000);
	}

}
