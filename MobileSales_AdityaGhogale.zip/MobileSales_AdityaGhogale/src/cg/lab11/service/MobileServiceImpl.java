package cg.lab11.service;

import cg.lab11.bean.Mobile;
import cg.lab11.dao.MobileDao;
import cg.lab11.dao.MobileDaoImpl;

public class MobileServiceImpl implements MobileService {

	private static MobileDao ms;
	/*@Override
	public int addMobile(int mobileId, Mobile mobile) {
		// TODO Auto-generated method stub
		return 0;
	}*/

	public MobileServiceImpl() {
		ms=new MobileDaoImpl();
	}

	@Override
	public boolean delete(int id) {
		ms.delete(id);
		return true;
	}

	@Override
	public int showMobileList() {
		ms.showMobileList();
		return 0;
		
	}



	@Override
	public void search(int sAmount, int fAmount) {
		ms.search(sAmount,fAmount);
		
	}

}
