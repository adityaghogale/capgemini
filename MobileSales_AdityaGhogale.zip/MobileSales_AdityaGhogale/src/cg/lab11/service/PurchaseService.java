package cg.lab11.service;

public interface PurchaseService {
	int placeOrder(int custId, int mobileId);

	void viewDetails(int purchaseId);
}
