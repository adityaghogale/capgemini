package cg.lab11.service;

import java.util.Random;

import cg.lab11.dao.PurchaseDao;
import cg.lab11.dao.PurchaseDaoImpl;

public class PurchaseServiceImpl implements PurchaseService {

	private static PurchaseDao pdao;
	public PurchaseServiceImpl() {
		pdao=new PurchaseDaoImpl();
	}

	@Override
	public int placeOrder(int custId, int mobileId) {
		int purchaseId=generatePurchaseId();
		pdao.placeOrder(purchaseId, custId, mobileId);
		return purchaseId;
	}

	@Override
	public void viewDetails(int purchaseId) {
		pdao.viewDetails(purchaseId);

	}

	private final int generatePurchaseId(){
		Random r=new Random();
		return r.nextInt(10000);
	}

}
