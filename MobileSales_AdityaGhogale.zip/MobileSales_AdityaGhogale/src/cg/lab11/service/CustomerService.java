package cg.lab11.service;

import cg.lab11.bean.Customer;

public interface CustomerService {
	int addCustomer(Customer cust);

	Customer search(int custKey);

	boolean delete(int id);
	String namePattern="[A-Za-z ]{4,}";
	
	String mobilePattern="[7-9][0-9]{9}";
	
	String emailPattern="^[A-Za-z0-9+_.-]+@(.+)$";
	
	static boolean validateName(String name) {
		return name.matches(namePattern);
	}
	
	static boolean validateMobile(String mobile) {
		return mobile.matches(mobilePattern);
	}
	
	static boolean validateEmail(String email) {
		return email.matches(emailPattern);
	}


}
