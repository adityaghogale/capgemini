package cg.lab11.bean;

public class PurchaseDetails {

	private int purchaseId;

	public int getOrderId() {
		return purchaseId;
	}

	public void setOrderId(int piurchaseId) {
		this.purchaseId = purchaseId;
	}
}
