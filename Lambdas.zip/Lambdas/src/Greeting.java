@FunctionalInterface
public interface Greeting {

	String sayHello();
	default String sayGoodBye(){
		return "Good Bye";
	}
	
	default String whatEver(){
		return sayHello(); //we can call abstract methods in default because to call default we need object of interface and class 
	}
	
	static void greet(){
		/*Greeting g=()->"Hello";
		System.out.println(g.sayHello());*/ 
		System.out.println("In greet");// we cannot call abstract method in static like in default
	}
}
