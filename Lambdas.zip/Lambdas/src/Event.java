
public interface Event {

	void perform();
}


