package MethodReference;

interface TestInterface{
	public void show(int n);
}

public class Test {

	public static void main(String[] args) {
		
		TestInterface testI=System.out::println;
		
		testI.show(3);
	}

}
