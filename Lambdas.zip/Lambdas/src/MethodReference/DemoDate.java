package MethodReference;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZonedDateTime;

public class DemoDate {

	public static void main(String[] args) {
		LocalDate lc=LocalDate.now();
		System.out.println(lc);
		System.out.println(lc.getDayOfMonth());
		System.out.println(lc.getDayOfYear());
		System.out.println(lc.getMonthValue());
		System.out.println(lc.getDayOfWeek());
		System.out.println(lc.getMonth());
		System.out.println(lc.getYear());
		System.out.println(lc.getEra());
		LocalDate ld=LocalDate.of(2020, 04, 13);
		System.out.println(lc.isBefore(ld));
		System.out.println(lc.isAfter(ld));
		System.out.println(lc.isLeapYear());
		System.out.println(lc.isEqual(ld));

		System.out.println(lc.plusDays(3));
		System.out.println(lc.plusMonths(4));
		System.out.println(lc.plusYears(2));
		
		System.out.println(lc.minusDays(3));
		System.out.println(lc.minusMonths(4));
		System.out.println(lc.minusYears(2));

		ZonedDateTime zd=ZonedDateTime.now();
		System.out.println(zd);
		
		Period p=lc.until(ld);
		System.out.println(p.getDays());
		
	}

}
