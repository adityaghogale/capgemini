package MethodReference;

interface MyInterface{
	public void interfaceMethod(String input);

}
public class Test2 {

	public static void staticMethod(String input){
		System.out.println("Static method :"+input);
	}
	public void method1(String input){
		System.out.println("Normal method:"+input);
	}
	
	public static void main(String[] args){
		
		Test2 obj=new Test2();
		
		MyInterface dd=obj::method1;
		dd.interfaceMethod("test string");
		MyInterface second=Test2::staticMethod;
		second.interfaceMethod("test Static string");		
	}
}
