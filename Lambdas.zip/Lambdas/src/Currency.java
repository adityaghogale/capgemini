
public interface Currency {

	double dollarValue();
	static double convert(Currency src,Currency tgt,double amt){
		return (src.dollarValue()/tgt.dollarValue())*amt;
	}
	
	Currency USD=()->1.0; //by default it is public static final
	static Currency INR=()->70.0;
	static Currency AED=()->3.5;
}
