
public class GreetingDemo {

	public static void main(String[] args) {
		Greeting g=() -> "Hello World";
		System.out.println(g.sayHello());
		System.out.println(g.sayGoodBye());
		System.out.println(g.whatEver());
		Greeting.greet();// as greet() is a static method
		
		Greeting g2=()-> {
			String msg="Namaste";
			return msg;
		};
		System.out.println(g2.sayHello());
	}

}
