package mydemo;

import java.util.Arrays;

public class OutOfStockException extends Exception {

	@Override
	public String toString() {
		return "Product Out Of Stock";
	}

	
}
