package mydemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo22 {
	
	//Will confirm a purchase and add record to purchasedetails table
public void delete(int id){
	try {
		DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
		Connection conn = 
		DriverManager.getConnection (
		"jdbc:oracle:thin:@localhost:1521:XE", "adi", "a1234");
		Statement stmt = conn.createStatement (); 
		int count = stmt.executeUpdate ("delete from mobiles where mobileid="+id);
		System.out.println("No of Records deleted :="+count);
		}
	catch (Exception e) {
		System.out.println(e);
	}
		
}


	public static void main(String[] args) {
		Demo22 d=new Demo22();
		d.delete(1004);

	}

}
