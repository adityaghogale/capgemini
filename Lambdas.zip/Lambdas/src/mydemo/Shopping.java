package mydemo;

public class Shopping {
	
	public String order(Product p,Integer qty) throws OutOfStockException{
		if(p.getStock()<qty) throw new OutOfStockException();
		else{
			p.setStock(p.getStock()-qty);
			return "Order SuccessFully Placed!";
			
		}
	}

	public static void main(String[] args) {
		Product p1=new Product("Bra",100);
		Product p2=new Product("Panty",100);
		Product p3=new Product("Phone",3);
		Shopping s1=new Shopping();
		try {
			s1.order(p1, 50);
			s1.order(p2,150);
			s1.order(p3,3);
		} catch (OutOfStockException e) {
			System.out.println(e);
		}

	}

}
