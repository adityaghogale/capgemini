package mydemo;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;



public class TestOrder {
	private Shopping shop = new Shopping();;
	
	@Before
	public void init() {
		
	}
	
	@After
	public void clean() {
		shop = null;
	}
	
	@Test
	public void testOrderSuccess() throws OutOfStockException {
		Product p = new Product("Apple", 10);
		assertEquals("Order SuccessFully Placed!",shop.order(p, 5));
	}
	
	@Test(expected = OutOfStockException.class)
	public void testOrderFailed() throws OutOfStockException {
		Product p = new Product("Cherry", 5);
		shop.order(p, 10);
	}
	
	@Test
	public void testOrderFailedMessage() {
		Product p = new Product("Kiwi", 2);
		try {
			shop.order(p, 3);
		} catch (OutOfStockException e) {
			assertEquals("Product Out Of Stock", e.toString());
		}
	}
}
