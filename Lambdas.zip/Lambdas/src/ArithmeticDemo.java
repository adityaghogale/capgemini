import java.util.Scanner;


public class ArithmeticDemo {

	public static void main(String[] args) {
		Arithmetic ar=(x,y) -> x+y;
		System.out.println(ar.square(3,5));

	}

}
