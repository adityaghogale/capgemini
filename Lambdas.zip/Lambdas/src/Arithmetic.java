
public interface Arithmetic {
 int square(int num,int num2);
}
