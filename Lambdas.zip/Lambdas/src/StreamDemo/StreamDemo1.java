package StreamDemo;

import java.util.Arrays;
import java.util.List;

public class StreamDemo1 {

	public static void main(String[] args) {
		
		List<Integer> numbers= Arrays.asList(2,5,7,10,2);
		numbers.stream().distinct().forEach(System.out::println);
		System.out.println("--------------------------------");
		
		
		numbers.stream().filter(n-> n >= 5).forEach(System.out::print);
		
		System.out.println("---------------------");
		
		numbers.stream().limit(3).forEach(System.out::println);
		
		System.out.println("---------------");
		
		numbers.stream().distinct().sorted().forEach(System.out::println);
		System.out.println("-----------------");
		
		System.out.println(numbers.stream().reduce(0,Integer::sum));
		
		String array[]={"Foo","Alpha","Romeo","Indigo","Beta","King","g"};
		
		List<String> input=Arrays.asList(array);
		
		input.forEach(System.out::println);
		
		input.stream().map(alpha -> alpha.toUpperCase()).sorted().forEach(System.out::println);
		
		
		input.stream().forEach(System.out::println);
		
		input.stream().parallel().forEach(System.out::println);
		
		List<String> words=Arrays.asList("Igate","Global","Solutions");
		words.stream().map(str->str.length()).forEach(System.out::println);
		
	}
	
}
