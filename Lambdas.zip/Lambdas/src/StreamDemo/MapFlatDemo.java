package StreamDemo;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MapFlatDemo {

	public static void main(String[] args) {
		Map<String,String> people=new HashMap<>();
		people.put("John","Mumbai");
		people.put("Mary", "Pune");
		people.put("Steve", "Bangalore");
		
		List<String> cities=people.values().stream().map(ct ->ct.toUpperCase()).collect(Collectors.toList());
		
		cities.forEach(System.out::println);
		
		Map<String,List<String>> contacts=new HashMap<>();
		
		contacts.put("John",Arrays.asList("555-555","653-746"));
		contacts.put("Mary",Arrays.asList("534-555","523-746"));
		contacts.put("Steve",Arrays.asList("527-555","853-746"));
		
		List<String> phones=contacts.values().stream().flatMap(Collection::stream).collect(Collectors.toList());
		//flatMap will reduce Arrays of two column to one single long one 
		phones.forEach(System.out::println);
		
	}

}
