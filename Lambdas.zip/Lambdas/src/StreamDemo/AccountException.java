package StreamDemo;

public class AccountException  extends Exception{
	double balance;

	public AccountException(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "AccountException [balance=" + balance + "]";
	}
	

}
