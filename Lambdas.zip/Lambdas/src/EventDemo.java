
public class EventDemo {

	public class FirstEventImpl implements Event{

		@Override
		public void perform() {
			System.out.println("First Performance");		
		}
		
	}
	public void firstEvent(){
		
		Event e=new FirstEventImpl();
		e.perform();
	}
	public void secondEvent(){
		 class secondEventImpl implements Event{ //private/public class can be local/global ...as it is inside method cannot be done

			@Override
			public void perform() {
				System.out.println("Second Performance");
				
			}
			
		}
		Event e=new secondEventImpl();
		e.perform();
		
	}
	public void thirdEvent(){
		
		Event e=new Event() {  //this is an anonymous inner class ..saved as EventDemo$1.class 
			
			@Override
			public void perform() {
				System.out.println("Third Performance");
				
			}
		};
		e.perform();
		/*new Event() {  //here event represents super class....and our class starts from () which converts everything inside currly brackets part of constructor
			
			@Override
			public void perform() {
				System.out.println("Third Performance");
				
			}
		}.perform();*/
		
	}
	
	public void fourthEvent(){
		Event e=()-> System.out.println("Fourth Performance");  //this is lambda expression...there will be no class file for lambda expressions though they are kind of implementations for interfaces and provide objects for methods
		e.perform();
		
	}
	public static void main(String[] args){
		EventDemo ed=new EventDemo();
		ed.firstEvent();
		FirstEventImpl fe=ed.new FirstEventImpl();
		//if above class is static and we want to create object of it outside
		//FirstEventImpl fe=new EventDemo.FirstEventImpl();
		fe.perform();
		ed.secondEvent();
		ed.thirdEvent();
		ed.fourthEvent();
	}
}
