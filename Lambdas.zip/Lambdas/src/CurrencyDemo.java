
public class CurrencyDemo implements Currency{

	public static void main(String[] args) {
	System.out.println(Currency.convert(Currency.USD,Currency.INR, 100));
	System.out.println(Currency.convert(Currency.INR,Currency.USD, 100));
	System.out.println(Currency.convert(Currency.AED,Currency.INR, 100));
	System.out.println(Currency.convert(Currency.INR,Currency.AED, 100));
	}

	@Override
	public double dollarValue() {
		return 0;
	}

}
